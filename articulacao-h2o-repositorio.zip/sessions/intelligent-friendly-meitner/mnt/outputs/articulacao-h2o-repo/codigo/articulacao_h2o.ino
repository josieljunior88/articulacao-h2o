/*
 * ============================================================
 *   ARTICULAÇÃO H₂O — Garra Hidráulica com Arduino
 *   Equipe ECAT 16 | IFAM Turma 2026.1
 * ============================================================
 *  Pinos:
 *    STEP   → 2   (pulso de passo para o driver)
 *    DIR    → 3   (direção de rotação)
 *    ENABLE → 4   (habilita/desabilita o motor)
 *    BTN_FECHAR → 8  (botão para fechar a garra)
 *    BTN_ABRIR  → 9  (botão para abrir a garra)
 *
 *  Lógica:
 *    - Limite de passos (MAX_PASSOS) protege o mecanismo
 *    - ENABLE HIGH desliga o motor quando inativo (economia)
 *    - INPUT_PULLUP: botão pressionado = LOW
 * ============================================================
 */

#define STEP        2
#define DIR         3
#define ENABLE      4
#define BTN_FECHAR  8
#define BTN_ABRIR   9

const int VELOCIDADE  = 600;   // microsegundos entre pulsos (menor = mais rápido)
const int MAX_PASSOS  = 800;   // limite máximo de passos (ajuste conforme mecanismo)
int posicaoAtual = 0;

void setup() {
  pinMode(STEP,       OUTPUT);
  pinMode(DIR,        OUTPUT);
  pinMode(ENABLE,     OUTPUT);
  pinMode(BTN_FECHAR, INPUT_PULLUP);
  pinMode(BTN_ABRIR,  INPUT_PULLUP);
  digitalWrite(ENABLE, LOW);   // motor habilitado ao iniciar
}

// Função auxiliar: envia um pulso de passo
void darPasso(bool direcao) {
  digitalWrite(DIR,  direcao);
  digitalWrite(STEP, HIGH);
  delayMicroseconds(5);
  digitalWrite(STEP, LOW);
  delayMicroseconds(VELOCIDADE);
}

void loop() {
  bool fechar = (digitalRead(BTN_FECHAR) == LOW);
  bool abrir  = (digitalRead(BTN_ABRIR)  == LOW);

  if (fechar && posicaoAtual < MAX_PASSOS) {
    darPasso(HIGH);
    posicaoAtual++;
  }

  if (abrir && posicaoAtual > 0) {
    darPasso(LOW);
    posicaoAtual--;
  }

  // Desativa motor quando nenhum botão está pressionado
  if (!fechar && !abrir) {
    digitalWrite(ENABLE, HIGH);
  } else {
    digitalWrite(ENABLE, LOW);
  }
}
