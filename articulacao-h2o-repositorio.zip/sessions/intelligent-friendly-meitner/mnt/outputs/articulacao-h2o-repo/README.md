# 💧 Articulação H₂O — Automação Hidráulica com Seringa e Precisão

> **Projeto acadêmico** | Introdução à Engenharia — Turma 2026.1  
> **Instituição:** IFAM — Instituto Federal do Amazonas (CMDI)  
> **Professor:** José Pinheiro de Queiroz Neto  
> **Evento:** Mostra 18/05/2026 · Hall da CDI · 14h–18h

---

## 👥 Equipe ECAT 16

| Nome | Função na Apresentação |
|------|----------------------|
| Josiel Severino da Silva Junior | Narrador / Líder |
| Davi Maciel Fernandes Pessoa | Suporte Técnico |
| Rosber Andrade França | Operador do Protótipo |

---

## 📌 Sobre o Projeto

O **Braço Articulado H₂O** é um protótipo eletro-hidráulico que demonstra a **Lei de Pascal** (P = F/A) por meio de um sistema de garras controlado por seringas interligadas por tubos de silicone. A eletrônica utiliza **Arduino UNO + Motor NEMA17** para converter movimento rotacional em pressão hidráulica, acionando a garra com precisão milimétrica.

### Princípio de Funcionamento

```
Botão → Arduino UNO → Driver 2M658 → Motor NEMA17
      → Fuso de chumbo → Pistão (seringa mestra)
      → Pressão hidráulica → Seringas escravas → GARRA
```

---

## 🔧 Materiais Utilizados

| Componente | Qtd | Especificação |
|-----------|-----|---------------|
| Seringas | 8 | 10 ml |
| Tubo de silicone | 8 m | Ø3mm int / Ø5mm ext |
| Chapas MDF | 15 pçs | 6 mm, corte CNC laser CO₂ |
| Peças ABS | 13 | Impressão 3D — juntas e conectores |
| Arduino UNO | 1 | Microcontrolador |
| Driver 2M658 | 1 | Step/Dir, 24V |
| Motor NEMA17 | 1 | Passo, 1.8°/step |
| Fonte 24V | 1 | Alimentação |
| Botões | 2 | Fechar / Abrir garra |

---

## 💻 Código Arduino

Veja o arquivo [`codigo/articulacao_h2o.ino`](codigo/articulacao_h2o.ino).

```cpp
#define STEP        2
#define DIR         3
#define ENABLE      4
#define BTN_FECHAR  8
#define BTN_ABRIR   9

const int VELOCIDADE  = 600;
const int MAX_PASSOS  = 800;
int posicaoAtual = 0;

void setup() {
  pinMode(STEP, OUTPUT); pinMode(DIR, OUTPUT); pinMode(ENABLE, OUTPUT);
  pinMode(BTN_FECHAR, INPUT_PULLUP); pinMode(BTN_ABRIR, INPUT_PULLUP);
  digitalWrite(ENABLE, LOW);
}

void darPasso(bool direcao) {
  digitalWrite(DIR, direcao);
  digitalWrite(STEP, HIGH); delayMicroseconds(5);
  digitalWrite(STEP, LOW);  delayMicroseconds(VELOCIDADE);
}

void loop() {
  bool fechar = (digitalRead(BTN_FECHAR) == LOW);
  bool abrir  = (digitalRead(BTN_ABRIR)  == LOW);

  if (fechar && posicaoAtual < MAX_PASSOS) { darPasso(HIGH); posicaoAtual++; }
  if (abrir  && posicaoAtual > 0)          { darPasso(LOW);  posicaoAtual--; }

  if (!fechar && !abrir) digitalWrite(ENABLE, HIGH);
  else                   digitalWrite(ENABLE, LOW);
}
```

---

## 📐 Conceitos de Engenharia Aplicados

| Conceito | Aplicação no Projeto |
|----------|---------------------|
| **Lei de Pascal** | P = F/A — pressão transmitida uniformemente |
| **Fuso de chumbo** | Converte rotação → deslocamento linear |
| **Microcontrolador** | Arduino lê botões, envia pulsos Step/Dir |
| **Driver de motor** | 2M658 amplifica sinais do Arduino para o NEMA17 |
| **Controle por posição** | Limite de passos evita dano mecânico |

---

## 📁 Estrutura do Repositório

```
articulacao-h2o/
├── README.md
├── codigo/
│   └── articulacao_h2o.ino     ← Código Arduino completo
├── documentos/
│   ├── descricao_tecnica.pdf   ← Descrição técnica do protótipo
│   ├── roteiro_apresentacao.pdf← Roteiro da apresentação
│   └── Articulacao_H2O_Blueprint.pdf ← Slides da apresentação
├── cartaz/
│   └── cartaz_tv_dark_hd.pdf   ← Cartaz para projeção
└── imagens/
    └── qrcode_repositorio.png  ← QR Code deste repositório
```

---

## 🎓 Para Estudantes

Este repositório foi criado para que **todos os alunos do IFAM CMDI** possam:

- Estudar como funciona automação hidráulica de baixo custo
- Reutilizar o código Arduino para seus próprios projetos
- Entender a integração entre mecânica, hidráulica e eletrônica
- Aprender sobre o processo de documentação de projetos de engenharia

---

## 📜 Licença

Este projeto é de uso **educacional livre**. Você pode estudar, modificar e compartilhar, desde que cite a origem:  
*Equipe ECAT 16 — IFAM Turma 2026.1*

---

*"A engenharia não é apenas sobre máquinas — é sobre resolver problemas com criatividade."*  
**Equipe Articulação H₂O 💧**
